import React from 'react'
import { Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const NavBarComponent = () => {
    const {isAuthenticated,login , logout} = useAuth();
    const navigate = useNavigate();
    const logoutUser = () => {
    logout()
    navigate("/login")
  }
  return (
    <Navbar expand="lg" bg="dark" variant="dark" className="shadow-sm">
      <Container>
        <Navbar.Brand href="/" className="fw-bold text-warning">Employee</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link href="/" className="px-3">View Employee</Nav.Link>
            <Nav.Link href="/addemp" className="px-3">Add Employee</Nav.Link>
            <Nav.Link href="/register" className="px-3">Register</Nav.Link>
            <Nav.Link href="/login" className="px-3">Login</Nav.Link>
          </Nav>
                <Button  onClick={logoutUser}>Logout</Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default NavBarComponent;
