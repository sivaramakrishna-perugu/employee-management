import React from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import NavBarComponent from './components/NavBarComponent'
import Employeeview from './pages/Employeeview'
import AddEmployee from './pages/AddEmployee'
import ViewSingleEmployee from './pages/ViewSingleEmployee'
import UpdateEmployee from './pages/UpdateEmployee'
import { ToastContainer } from 'react-toastify'
import RegisterForm from './pages/RegisterForm'
import LoginForm from './pages/LoginForm'
import ProtectedRoutes from './routes/ProtectedRoutes'
import { AuthProvider } from './AuthContext'
const App = () => {
  return (
    <AuthProvider>
    <BrowserRouter>
    <ToastContainer/>
    <NavBarComponent/>

    <Routes>
      <Route path='/' element={<ProtectedRoutes><Employeeview/></ProtectedRoutes>}></Route>
      <Route path='/addemp/' element={<ProtectedRoutes><AddEmployee/></ProtectedRoutes>}></Route>
      <Route path='/update/:empid' element={<UpdateEmployee/>}/>
      <Route path='/singleemp/:id' element={<ViewSingleEmployee/>}></Route>
      <Route path='/register' element={<RegisterForm/>}/>
      <Route path='/login' element={<LoginForm/>}/>
    </Routes>
      
    </BrowserRouter>
    </AuthProvider>
  )
}

export default App
