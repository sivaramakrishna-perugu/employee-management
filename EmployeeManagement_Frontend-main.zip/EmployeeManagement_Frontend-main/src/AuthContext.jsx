// AuthContext.jsx
import { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loginResponse = localStorage.getItem("loginResponse");
    if (loginResponse) {
      try {
        const parsed = JSON.parse(loginResponse); // ✅ safe now
        setIsAuthenticated(true);
        setUser(parsed);
      } catch (err) {
        console.error("Failed to parse loginResponse:", err);
        localStorage.removeItem("loginResponse"); // cleanup bad value
      }
    }
  }, []);

  const login = (data) => {
    localStorage.setItem("loginResponse", JSON.stringify(data)); // ✅ stringify object
    setIsAuthenticated(true);
    setUser(data);
  };

  const logout = () => {
    localStorage.removeItem("loginResponse");
    setIsAuthenticated(false);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
