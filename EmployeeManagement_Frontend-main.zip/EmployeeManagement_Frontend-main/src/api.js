// src/api.js
import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8080", // Spring Boot backend
});

API.interceptors.request.use((config) => {
  const loginResponse = localStorage.getItem("loginResponse");
  if (loginResponse) {
    const { token } = JSON.parse(loginResponse); // ✅ safe now
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log("Auth header:", config.headers.Authorization);
    }
  }
  return config;
});

export default API;
