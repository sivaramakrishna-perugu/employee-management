// ProtectedRoutes.jsx
import React from "react";
import { Navigate } from "react-router-dom";

const ProtectedRoutes = ({ children, allowedRoles = [] }) => {
  const loginResponse = localStorage.getItem("loginResponse");
  let user = null;

  try {
    user = loginResponse ? JSON.parse(loginResponse) : null;
  } catch (err) {
    console.error("Invalid loginResponse", err);
    localStorage.removeItem("loginResponse");
  }

  if (!user) {
    // Not logged in
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    // Logged in but wrong role
    return <Navigate to="/" replace />;
    // Or: return <div>Access Denied</div>;
  }

  return children;
};

export default ProtectedRoutes;
