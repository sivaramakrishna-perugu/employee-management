import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';

const ViewSingleEmployee = () => {
  const { id } = useParams();
  const [employee, setEmployee] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:8080/getEmp/${id}`);
        setEmployee(res.data);
      } catch (err) {
        console.error("Error fetching employee:", err);
      }
    };
    fetchData();
  }, [id]);

  return (
    <div className="employee-bg">
      <Container className="d-flex justify-content-center align-items-center min-vh-100">
        <Row className="w-50">
          <Col>
            <h2 className="text-center mb-4 text-light">Single Employee Details</h2>
            {employee ? (
              <Card className="employee-card shadow-lg p-4">
                <Card.Body>
                  <Card.Title className="text-primary fw-bold mb-3">
                    Employee Information
                  </Card.Title>
                  <p><strong>ID:</strong> {employee.empid}</p>
                  <p><strong>Name:</strong> {employee.empname}</p>
                  <p><strong>Salary:</strong> ₹{employee.empsal}</p>
                  <div className="text-center mt-3">
                    <Link to="/">
                      <Button variant="secondary" className="px-4">
                        🏠 Home
                      </Button>
                    </Link>
                  </div>
                </Card.Body>
              </Card>
            ) : (
              <p className="text-muted text-center">No data found for ID {id}</p>
            )}
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default ViewSingleEmployee;
