

import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from 'axios';
import { toast } from 'react-toastify';

const UpdateEmployee = () => {
     const [formdata,setformdata]= useState({
        empname:"",
        empsal:"",
     })
  const { empid } = useParams();
  console.log(empid);
   const navigate = useNavigate();
  useEffect(()=>{
     const fetchData = async()=>{
        const res = await axios.get(`http://localhost:8080/getEmp/${empid}`)
         console.log(res);
         setformdata(res.data)
     }
     fetchData();
   },[])

   const handleChangeInput= async(e)=>{
    e.preventDefault();
     setformdata({...formdata,[e.target.name]:e.target.value})
   }

    const handleSubmit=async(e)=>{
         e.preventDefault();
   try{
     await axios.put(`http://localhost:8080/update/${empid}`,formdata)
     toast.success("Update Employee data")
     navigate("/")
   }catch(err){
     toast.error(err);
   }
 
   }

  return (
    <Container className="d-flex justify-content-center align-items-center min-vh-100">
      <Row className="w-50">
        <Col>
          <h2 className="text-center mt-4 mb-4">Update Employee</h2>
          <Form className="p-4 shadow rounded bg-light" onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formEmpName">
              <Form.Label>Employee Name</Form.Label>
              <Form.Control type="text" placeholder="Enter employee name"
               
               name='empname'
               value={formdata.empname}
               onChange={handleChangeInput}
               />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formEmpSalary">
              <Form.Label>Employee Salary</Form.Label>
              <Form.Control type="number" placeholder="Enter salary" 
               name='empsal'
               value={formdata.empsal}
              
               onChange={handleChangeInput}
              />
            </Form.Group>

          

            <div className="text-center">
              <Button variant="primary" type="submit" className="px-5">
                Update Employee
              </Button>
            </div>
          </Form>
        </Col>
        <Link to="/">Back To home</Link>
      </Row>
    </Container>
  )
}

export default UpdateEmployee;
