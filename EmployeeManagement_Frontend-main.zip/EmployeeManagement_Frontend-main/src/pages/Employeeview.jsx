import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import { Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';

const Employeeview = () => {
  const [employee, setEmployee] = useState([]);
   const navigation = useNavigate();

   const fetchData = async () => {
      try {
        const res = await axios.get("http://localhost:8080/getAll");
        setEmployee(res.data);
      } catch (err) {
        console.error("Error fetching employees:", err);
      }
    };

  useEffect(() => {
   
    fetchData();
  }, []);


  const singleEmp = async(id)=>{
    navigation(`singleemp/${id}`)
  }

  const editEmp = async(id)=>{
    navigation(`/update/${id}`);

  }


    const deleteEmp = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/delete/${id}`);
      fetchData(); // refresh list after delete
    } catch (err) {
      console.error("Error deleting employee:", err);
    }
  };

  return (
    <Container className="mt-4">
      <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h1 className="mb-0">Employee Details</h1>
        <Link to="/addemp">
          <Button variant="success">+ Add Employee</Button>
        </Link>
      </div>
  {employee && employee.length > 0 ? (
      <Table striped bordered hover responsive>
        <thead className="table-dark">
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Salary</th>
            <th style={{ width: "220px" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
        
            {employee.map((emp, i) => (
              <tr key={i}>
                <td>{emp.empid}</td>
                <td>{emp.empname}</td>
                <td>{emp.empsal}</td>
                <td>
                  <Button variant="primary" size="sm" className="me-2" onClick={()=>editEmp(emp.empid)}>
                    Edit
                  </Button>
                  <Button variant="info" size="sm" className="me-2" onClick={()=>singleEmp(emp.empid)}>
                    View
                  </Button>
                  <Button variant="danger" size="sm" onClick={()=>deleteEmp(emp.empid)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          
        </tbody>
      </Table>
  ):
   (
            <tr>
              <td colSpan="4" className="text-center text-muted">
                Data  Not Found
              </td>
            </tr>
          )}
          </div>
    </Container>
  );
};

export default Employeeview;
