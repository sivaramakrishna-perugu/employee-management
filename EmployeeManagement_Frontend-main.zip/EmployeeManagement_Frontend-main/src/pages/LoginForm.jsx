// src/LoginForm.jsx
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { useState } from "react";
import { toast } from "react-toastify";
import API from "../api";

const LoginForm = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [credentials, setCredentials] = useState({ username: "", password: "" });

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/login", credentials);

      console.log("Backend response:", res.data); // ✅ debug log

      toast.success("Login Successfully");

      login(res.data); // ✅ pass JSON object to AuthContext

      navigate("/");
    } catch (err) {
      alert("Login Failed: " + (err.response?.data?.message || err.message));
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow">
            <div className="card-header bg-primary text-white text-center">
              <h4>Login</h4>
            </div>
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">Username</label>
                  <input
                    type="text"
                    name="username"
                    className="form-control"
                    value={credentials.username}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label">Password</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    value={credentials.password}
                    onChange={handleChange}
                    required
                  />
                </div>

                <button type="submit" className="btn btn-success w-100">
                  Login
                </button>
                <p className="mt-3 text-center">
                  If you don’t have an account,{" "}
                  <Link to="/register">
                    <span>Register</span>
                  </Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
