

import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from 'axios';
import { toast } from 'react-toastify';


const AddEmployee = () => {
   const[formdata,setformdata]=useState({
    empname:"",
    empsal:""
   })
  const navigate = useNavigate();

   const handleChangeInput=(e)=>{
      setformdata({...formdata,[e.target.name]:e.target.value})
   }

    const handleSubmit = async(e)=>{
      e.preventDefault();
       try{
       await axios.post("http://localhost:8080/add",formdata)
        toast.success("Employee added")
        navigate("/")

    } catch(err){
      toast.error(err);
    }
  }
  return (
      <Container className="d-flex justify-content-center align-items-center min-vh-100">
      <Row className="w-50">
        <Col>
          <h2 className="text-center mt-4 mb-4">Add Employee</h2>
          <Form className="p-4 shadow rounded bg-light" onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formEmpName">
              <Form.Label>Employee Name</Form.Label>
              <Form.Control type="text" placeholder="Enter employee name"
               
               name='empname'
               value={formdata.empname}
               onChange={handleChangeInput}
               />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formEmpSalary">
              <Form.Label>Employee Salary</Form.Label>
              <Form.Control type="number" placeholder="Enter salary" 
               name='empsal'
               value={formdata.empsal}
              
               onChange={handleChangeInput}
              />
            </Form.Group>

          

            <div className="text-center">
              <Button variant="primary" type="submit" className="px-5">
                Add Employee
              </Button>
            </div>
          </Form>
        </Col>
        <Link to="/">Back To home</Link>
      </Row>
    </Container>
  )
}

export default AddEmployee
