// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package com.excelr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.excelr.entity.LoginRequest;
import com.excelr.entity.User;
import com.excelr.services.UserService;

import jakarta.servlet.http.HttpSession;

@RestController
public class UserController {
   private UserService userService;

   @Autowired
   public UserController(UserService userService) {
      this.userService = userService;
   }

   @GetMapping({"/users"})
   public List<User> getUsers() {
      return this.userService.getUsers();
   }

   @GetMapping({"/user/{id}"})
   public User getUser(@PathVariable Integer id) {
      return this.userService.getUser(id);
   }

   @PutMapping({"/user/{id}"})
   public User updateUser(@RequestBody User user, @PathVariable Long id) {
      return this.userService.updateUser(user);
   }

   @PostMapping({"/register"})
   public ResponseEntity<User> newUser(@RequestBody User user) {
      User newUser = this.userService.addUser(user);
      return ResponseEntity.status(HttpStatus.CREATED).body(newUser);
   }

   @DeleteMapping({"/user/{id}"})
   public void deleteUser(@PathVariable Integer id) {
      this.userService.deleteUser(id);
   }@PostMapping("/login")
   public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest loginRequest, HttpSession session) {
	    Map<String, Object> response = new HashMap<>();
	    try {
	        boolean authenticated = userService.authenticate(loginRequest.getUsername(), loginRequest.getPassword());
	        if (authenticated) {
	            session.setAttribute("user", loginRequest.getUsername());

	            response.put("message", "Login successful");
	            response.put("username", loginRequest.getUsername());
	            response.put("role", "USER"); // or fetch from DB
	            response.put("sessionId", session.getId());

	            return ResponseEntity.ok(response);
	        } else {
	            response.put("message", "Invalid credentials");
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        response.put("message", "Login failed");
	        response.put("error", e.getMessage());
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	    }
	}
}