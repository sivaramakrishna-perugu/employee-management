package com.excelr.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.excelr.entity.Employee;
import com.excelr.services.EmployeeService;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class EmployeeController {

    @Autowired
    private EmployeeService empService;

    // Only ADMIN can add employees
    @PostMapping("/add")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
        empService.saveData(employee);
        return ResponseEntity.ok("Employee added successfully");
    }

    // USER or ADMIN can view all employees
    @GetMapping("/getAll")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<Employee> getAllEmployees() {
        return empService.getAllEmployee();
    }

    // USER or ADMIN can view employee by ID
    @GetMapping("/getEmp/{empid}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public Optional<Employee> getEmployeeById(@PathVariable Integer empid) {
        return empService.getById(empid);
    }

    // Only ADMIN can delete
    @DeleteMapping("/delete/{empid}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteById(@PathVariable Integer empid) {
        empService.DeleteById(empid);
        return "Delete Success";
    }

    // Only ADMIN can update
    @PutMapping("/update/{empid}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Employee> updateById(@PathVariable Integer empid,
                                               @RequestBody Employee updateEmp) {
        Employee updatedEmp = empService.updateById(empid, updateEmp);
        if (updatedEmp != null) {
            return new ResponseEntity<>(updatedEmp, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
