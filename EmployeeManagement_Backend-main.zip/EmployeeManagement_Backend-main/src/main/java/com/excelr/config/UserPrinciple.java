// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package com.excelr.config;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.excelr.entity.User;

public class UserPrinciple implements UserDetails {
   private User user;

   public UserPrinciple(User user) {
      this.user = user;
   }

   public Collection<? extends GrantedAuthority> getAuthorities() {
      return Collections.singleton(new SimpleGrantedAuthority("USER"));
   }

   public String getPassword() {
      return this.user.getPassword();
   }

   public String getUsername() {
      return this.user.getUsername();
   }

 
}
