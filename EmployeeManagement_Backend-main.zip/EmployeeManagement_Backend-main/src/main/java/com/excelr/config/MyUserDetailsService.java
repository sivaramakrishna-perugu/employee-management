// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package com.excelr.config;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.excelr.entity.User;
import com.excelr.repo.UserRrpo;


@Service
public class MyUserDetailsService {
   private final    UserRrpo userRepository;

   public MyUserDetailsService(UserRrpo userRepository) {
      this.userRepository = userRepository;
   }

   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
      User user = this.userRepository.findByUsername(username);
      System.out.println("security usernam " + username);
      if (user == null) {
         throw new UsernameNotFoundException("This user doent not exist in the DB");
      } else {
         System.out.println("User from DB " + String.valueOf(user));
         return new UserPrinciple(user);
      }
   }
}
