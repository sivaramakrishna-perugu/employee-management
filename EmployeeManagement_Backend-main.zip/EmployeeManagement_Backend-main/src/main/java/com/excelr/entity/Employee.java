package com.excelr.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer empid;
	 private String empname;
	 private int empsal;
	 public Employee() {
		super();
		// TODO Auto-generated constructor stub
	 }
	 public Employee(Integer empid, String empname, int empsal) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsal = empsal;
	 }
	 public Integer getEmpid() {
		 return empid;
	 }
	 public void setEmpid(Integer empid) {
		 this.empid = empid;
	 }
	 public String getEmpname() {
		 return empname;
	 }
	 public void setEmpname(String empname) {
		 this.empname = empname;
	 }
	 public int getEmpsal() {
		 return empsal;
	 }
	 public void setEmpsal(int empsal) {
		 this.empsal = empsal;
	 }
	 @Override
	 public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", empsal=" + empsal + "]";
	 }
	 
	

}
