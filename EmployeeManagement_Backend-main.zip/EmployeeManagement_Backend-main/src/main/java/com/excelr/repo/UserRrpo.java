package com.excelr.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.excelr.entity.User;
@Repository
public interface UserRrpo  extends JpaRepository<User, Integer>{

    User findByUsername(String username);
}
