package com.excelr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSysstemAssingmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSysstemAssingmentApplication.class, args);
	}

}
