package com.excelr.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.excelr.entity.Employee;
import com.excelr.repo.EmployeeRepo;
@Service
public class EmployeeService {
	 @Autowired
	private EmployeeRepo emprepo;
	 
	 public Employee saveData(Employee emp) {
		 return emprepo.save(emp);
	 }
	  public List<Employee> getAllEmployee(){
		  List<Employee> empdata=  emprepo.findAll();
		   return empdata;
	  }
	  // get By Id
	  public Optional<Employee> getById(Integer empid) {
	 Optional<Employee> emp=	    emprepo.findById(empid);
	  return emp;
	  }
	  
	   // Delete By Id
	  public String DeleteById(Integer empid) {
		    emprepo.deleteById(empid);
		     return "Delete success";
	  }
	  
	  // upadate By Id
	  public Employee updateById(Integer empid, Employee updateEmp) {
		    Optional<Employee> emp = emprepo.findById(empid);

		    if (emp.isPresent()) {
		        Employee existingEmployee = emp.get();
		        existingEmployee.setEmpname(updateEmp.getEmpname());
		        existingEmployee.setEmpsal(updateEmp.getEmpsal());
		        return emprepo.save(existingEmployee);
		    }
		    return null; // or throw exception if not found
		}

	

}
