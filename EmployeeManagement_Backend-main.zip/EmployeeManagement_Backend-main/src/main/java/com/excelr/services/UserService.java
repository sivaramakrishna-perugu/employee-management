// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package com.excelr.services;

import com.excelr.entity.User;
import com.excelr.repo.UserRrpo;

import java.util.List;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

@Service
@CrossOrigin(
   origins = {"*"}
)
public class UserService {
   private final BCryptPasswordEncoder bCryptPasswordEncoder;
   private final UserRrpo userRepository;

   public UserService(UserRrpo userRepository, BCryptPasswordEncoder bCryptPasswordEncoder) {
      this.userRepository = userRepository;
      this.bCryptPasswordEncoder = bCryptPasswordEncoder;
   }

   public List<User> getUsers() {
      return this.userRepository.findAll();
   }

   public User getUser(Integer id) {
      return (User)this.userRepository.findById(id).orElse((User)null);
   }

   public User addUser(User user) {
      user.setPassword(this.bCryptPasswordEncoder.encode(user.getPassword()));
      return (User)this.userRepository.save(user);
   }

   public User updateUser(User user) {
      return (User)this.userRepository.save(user);
   }

   public void deleteUser(Integer id) {
      this.userRepository.deleteById(id);
   }

   public boolean authenticate(String username, String password) {
      User user = this.userRepository.findByUsername(username);
      System.out.println("username " + username);
      System.out.println("user" + String.valueOf(user));
      if (user == null) {
         throw new UsernameNotFoundException("User not found");
      } else {
         System.out.println("Db password " + user.getPassword());
         boolean matched = this.bCryptPasswordEncoder.matches(password, user.getPassword());
         System.out.println("Password matched " + matched);
         if (!matched) {
            throw new BadCredentialsException("Wrong password");
         } else {
            return true;
         }
      }
   }
}
